// Copyright 2018 The Chromium Authors. All rights reserved.
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

// console.info('start to set plugin_fn');
// ====================================================================================
function set_style() {
    let style = document.createElement('style');
    style.type = 'text/css';
    style.innerHTML=".hintStyle{border:2px solid red;}";
    document.getElementsByTagName('HEAD').item(0).appendChild(style);
}
set_style();


// 向页面注入JS, 否则当前页面的js仅能方位popup弹出窗口的js内容, 作用不到我们真正关心的主页面.
function injectCustomJs(jsPath)
{
  jsPath = jsPath || 'js/inject.js';
  var temp = document.createElement('script');
  temp.setAttribute('type', 'text/javascript');
  // 获得的地址类似：chrome-extension://ihcokhadfjfchaeagdoclpnjdiokfakg/js/inject.js
  temp.src = chrome.extension.getURL(jsPath);
  temp.onload = function()
  {
    // 放在页面不好看，执行完后移除掉
    this.parentNode.removeChild(this);
  };
  document.head.appendChild(temp);
}


function mask_showDetail() {
    var temp = document.createElement('script');
    temp.setAttribute('type', 'text/javascript');
    temp.innerHTML = "function showDetail(var_a){console.info(var_a);};"
    document.head.appendChild(temp);

    // 或者下面这种方式将整个代码写在另外一个脚本中, 载入页面.
    // injectCustomJs('injects2main_page.js');
    // 需要在 manifest.json中加入如下内容:
    // // 普通页面能够直接访问的插件资源列表，如果不设置是无法直接访问的
    //"web_accessible_resources": ["injects2main_page.js"],
    console.info('setted.');
}


// ====================================================================================
// console.info('end  to set plugin_fn');

