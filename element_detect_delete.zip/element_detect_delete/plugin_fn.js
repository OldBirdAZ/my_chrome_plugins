// Copyright 2018 The Chromium Authors. All rights reserved.
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

// console.info('start inject');
// ====================================================================================
// 原生js
function set_style() {
    let style = document.createElement('style');
    style.type = 'text/css';
    style.innerHTML=".hintStyle{border:2px solid red;}";
    document.getElementsByTagName('HEAD').item(0).appendChild(style);
}
set_style();
function hasClass(elem, cls) {
  cls = cls || '';
  if (cls.replace(/\s/g, '').length == 0) return false; //当cls没有参数时，返回false
  return new RegExp(' ' + cls + ' ').test(' ' + elem.className + ' ');
}

function addClass(elem, cls) {
  if (!hasClass(elem, cls)) {
    elem.className = elem.className == '' ? cls : elem.className + ' ' + cls;
  }
}

function removeClass(elem, cls) {
  if (hasClass(elem, cls)) {
    var newClass = ' ' + elem.className.replace(/[\t\r\n]/g, '') + ' ';
    while (newClass.indexOf(' ' + cls + ' ') >= 0) {
      newClass = newClass.replace(' ' + cls + ' ', ' ');
    }
    elem.className = newClass.replace(/^\s+|\s+$/g, '');
  }
}

function mouse_over_fn(e) {
    // the mouse in
    addClass(e.target, 'hintStyle');
}
function mouse_out_fn(e) {
    // the mouse out
    removeClass(e.target, 'hintStyle');
}
function rm_elem(e) {
    e.target.remove();
}
function rclick_rm_elem(e) {
    e.preventDefault();
    e.target.remove();
}

function set_elem_show() {
    document.addEventListener('mouseover', mouse_over_fn);
    document.addEventListener('mouseout', mouse_out_fn);
    document.addEventListener('dblclick', rm_elem);
    document.addEventListener('contextmenu', rclick_rm_elem);
    // document.onmouseover = mouse_over_fn;
    // document.onmouseout = mouse_out_fn;
    // document.ondblclick = rm_elem;
}
function reset_elem_show() {
    // $(document).unbind('mouseover', mouse_over_fn);
    // $(document).unbind('mouseout', mouse_out_fn);
    // $(document).unbind('dblclick', rm_elem);
    document.removeEventListener('mouseover', mouse_over_fn);
    document.removeEventListener('mouseout', mouse_out_fn);
    document.removeEventListener('dblclick', rm_elem);
    document.removeEventListener('contextmenu', rclick_rm_elem);
}

  

// ====================================================================================
// console.info('end inject');

