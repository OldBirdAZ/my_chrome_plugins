// Copyright 2018 The Chromium Authors. All rights reserved.
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

// ====================================================================================
function fake_showDetail(a_var) {
    console.info(a_var);
    // a_var = 1+1;
};

showDetail = fake_showDetail;

// ====================================================================================

