// Copyright 2018 The Chromium Authors. All rights reserved.
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

// console.info('start to set plugin_fn');
// ====================================================================================
function set_style() {
    let style = document.createElement('style');
    style.type = 'text/css';
    style.innerHTML=".hintStyle{border:2px solid red;}";
    document.getElementsByTagName('HEAD').item(0).appendChild(style);
    console.info('setted style');
}
set_style();


// 向页面注入JS, 否则当前页面的js仅能方位popup弹出窗口的js内容, 作用不到我们真正关心的主页面.
// function injectCustomJs(jsPath)
// {
//   jsPath = jsPath || 'js/inject.js';
//   var temp = document.createElement('script');
//   temp.setAttribute('type', 'text/javascript');
//   // 获得的地址类似：chrome-extension://ihcokhadfjfchaeagdoclpnjdiokfakg/js/inject.js
//   temp.src = chrome.extension.getURL(jsPath);
//   temp.onload = function()
//   {
//     // 放在页面不好看，执行完后移除掉
//     this.parentNode.removeChild(this);
//   };
//   document.head.appendChild(temp);
// }


function injectCustomJs() {
    var temp = document.createElement('script');
    temp.setAttribute('type', 'text/javascript');
    // temp.innerHTML = "function mask_show_ad(){$('.cover-image-frame').remove();console.info('removed element: cover-image-frame');};"
    // temp.innerHTML = "$('.cover-image-frame').remove();console.info('removed element: cover-image-frame');"
    temp.innerHTML = "document.querySelector('.cover-image-frame').remove();console.info('removed element: cover-image-frame');"
    document.head.appendChild(temp);
    console.info('setted.');
}
// injectCustomJs();

// ====================================================================================
console.info('end to set plugin_fn');

