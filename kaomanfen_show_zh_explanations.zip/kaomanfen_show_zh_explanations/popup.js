// Copyright 2018 The Chromium Authors. All rights reserved.
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

'use strict';

let turnOnBtn = document.getElementById('turnOnBtn');
let turnOffBtn = document.getElementById('turnOffBtn');
// let turnOnOffBtn = document.getElementById('turnOnOffBtn');

// turnOnOffBtn.onclick = function(element) {
//   let onoffswitch = document.getElementById('onoffswitch');
//   val = onoffswitch.value;
//   turnOnOffBtn.html = 'hhh';
//   chrome.tabs.query({active: true, currentWindow: true}, function(tabs) {
//     chrome.tabs.executeScript(
//         tabs[0].id,
//         {code: "alert('"+ tabs[0].id +"')"});
//   });
// };

turnOnBtn.onclick = function(element) {
  chrome.tabs.query({active: true, currentWindow: true}, function(tabs) {
    chrome.tabs.executeScript(
        tabs[0].id,
        {code: "set_elem_show();"});
  });
};

turnOffBtn.onclick = function(element) {
  // status_bar.html = 'Off';
//   chrome.storage.sync.set({elem_detector_status: false}, function() {});
//   let color = element.target.value;
// });
  chrome.tabs.query({active: true, currentWindow: true}, function(tabs) {
    chrome.tabs.executeScript(
        tabs[0].id,
        {code: "reset_elem_show();"});
  });
};
