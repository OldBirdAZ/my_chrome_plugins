// Copyright 2018 The Chromium Authors. All rights reserved.
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

// console.info('start inject');
// ====================================================================================

function mask_showDetail() {
    var temp = document.createElement('script');
    temp.setAttribute('type', 'text/javascript');
    temp.innerHTML = "function showDetail(var_a){console.info(var_a);};"
    document.head.appendChild(temp);

    // 或者下面这种方式将整个代码写在另外一个脚本中, 载入页面.
    // injectCustomJs('injects2main_page.js');
    // 需要在 manifest.json中加入如下内容:
    // // 普通页面能够直接访问的插件资源列表，如果不设置是无法直接访问的
    //"web_accessible_resources": ["injects2main_page.js"],
    console.info('setted.');
}

function set_elem_show() {
    var temp = document.createElement('script');
    temp.setAttribute('type', 'text/javascript');
    temp.innerHTML = "$('.translation-box').attr('style', 'display: block');"
    document.head.appendChild(temp);
    console.info('setted.');
}
function reset_elem_show() {
    var temp = document.createElement('script');
    temp.setAttribute('type', 'text/javascript');
    temp.innerHTML = "$('.translation-box').attr('style', '');"
    document.head.appendChild(temp);
    console.info('setted.');
}

  

// ====================================================================================
// console.info('end inject');

